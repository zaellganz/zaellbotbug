const bye =  ` BYE YATIM`
exports.bye = bye