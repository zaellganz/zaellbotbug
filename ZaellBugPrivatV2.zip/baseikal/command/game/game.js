const game =  ` 


*Game Maker*
┏━━⊱
┣❏tebak lagu
┣❏tebak kata
┣❏tebak lirik
┣❏tebak kalimat
┣❏tebak gambar
┣❏tebak lontong
┣❏jadian
┣❏tictactoe
┣❏family100
┣❏math [mode]
┣❏suitpvp [@tag]
┣❏leaderboard
┣❏inventori
┣❏mining
┣❏beli
┣❏jual
┣❏heal
┣❏berburu
┣❏deltt
┗━━⊱[ Zaell Botz ]`
exports.game = game