const menu =  ` 
° Owner  : Zaell Ganz
° Version : 13
° Baileys : 5.0.0

┏━┳┳┳━┳┳┓
┃━┫┃┃┏┫━┫┏┓
┃┏┫┃┃┗┫┃┃┃┃
┗┛┗━┻━┻┻┛┃┃
┏┳┳━┳┳┳┓┏┫┣┳┓
┃┃┃┃┃┃┃┃┣┻┫┃┃
┣┓┃┃┃┃┣┫┃┏┻┻┫
┗━┻━┻━┻
 ▰▱▰▱▰▱▰▱▰▱▰▱▰▱
 ❍ BUG_MENU ❍
┏━━⊱
┣❏ Bugmenu
┗━━⊱
 ❍ ALL_MENU ❍
┏━━⊱
┣❏ Allmenu
┗━━⊱
❍ MENU_MODS ❍
┏━━⊱
┣❏ Game
┣❏ Cekbot
┣❏ Soundbot
┣❏ Sewa
┣❏ Textmaker
┗━━⊱
 ❍ MENU_LIST ❍
┏━━⊱
┣❏ Listaudio
┣❏ Listban
┣❏ Listjualan
┣❏ Listjualan2
┣❏ Listlogo
┣❏ Listasupan
┣❏ Listcecan
┣❏ Listjualan
┣❏ Listowner
┣❏ Listwibu
┣❏ Listprem
┗━━⊱
 ❍ MENU_OWNER ❍
┏━━⊱
┣❏ Addowner 628xx
┣❏ Delowner 628xx
┣❏ Addprem 628xx
┣❏ Delprem 628xxx
┣❏ Nowa 628xxx
┣❏ Verif 62xxxxx
┣❏ Ban add 628xx
┣❏ Ban del 628xx
┣❏ Addlist
┣❏ Dellist
┣❏ Updatelist
┗━━⊱
❍ MENU_GROUP ❍
┏━━⊱
┣❏ Antilink on / off
┣❏ Welcome on / off
┣❏ Detectadmin on / off
┣❏ Kick 628xxx
┣❏ Add 628xxx
┣❏ Promote 628xx
┣❏ Demote 628xx
┗━━⊱
 ▰▱▰▱▰▱▰▱▰▱▰▱▰▱`
exports.menu = menu