const allmenu =  ` 


*Maker Apikey*
┏━━⊱
┣❏ igdl
┣❏ igdl2
┣❏ twtdl
┣❏ fbdl
┗━━⊱
*Download Maker*
┏━━⊱
┣❏tiktokvideo
┣❏tiktokaudio
┣❏play
┣❏mediafire
┗━━⊱

*Sticker Maker*
┏━━⊱
┣❏sticker
┣❏stickergif
┣❏emojimix
┣❏emojimix2
┣❏smeme
┗━━⊱
*Audio & Image*
┏━━⊱
┣❏toimage
┣❏toonce
┣❏tomp4
┣❏tovn
┣❏togif
┣❏tourl 
┣❏toaud
┗━━⊱
*Image Maker*
┏━━⊱
┣❏pinterest
┣❏couple
┣❏coffe
┗━━⊱
*Only Group*
┏━━⊱
┣❏inspect
┣❏linkgroup
┣❏tagall
┣❏hidetag
┣❏group
┣❏setname
┣❏setdesc
┣❏editinfo
┣❏setppgroup
┗━━⊱
*Only Owner*
┏━━⊱
┣❏listpc
┣❏listgc
┣❏listonline
┣❏setppbot
┣❏block
┣❏unblock
┗━━⊱
*Cmd Maker*
┏━━⊱
┣❏listcmd
┣❏setcmd [ reply sticker ]
┣❏delcmd [ reply sticker ]
┗━━⊱
*Random*
┏━━⊱
┣❏ktpmaker
┣❏afk
┣❏ping
┣❏owner
┣❏getname
┣❏getpic
┣❏infochat
┣❏q
┣❏del
┣❏style
┣❏ss
┣❏penjara
┗━━⊱[ Zaell Botz ]`
exports.allmenu = allmenu